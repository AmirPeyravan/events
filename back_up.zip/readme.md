https://www.youtube.com/watch?v=jKpCxdN619c&ab_channel=SourceCodester
